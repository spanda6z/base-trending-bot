import type { VercelRequest, VercelResponse } from "@vercel/node";

export default async function handler(_req: VercelRequest, res: VercelResponse) {
  const checks = {
    status: "ok",
    timestamp: new Date().toISOString(),
    env: {
      hasTelegramToken: !!process.env.TELEGRAM_BOT_TOKEN,
      hasDatabase: !!process.env.DATABASE_URL,
      hasRpc: !!process.env.BASE_RPC_URL,
      chainId: process.env.BASE_CHAIN_ID || "8453",
    },
  };

  return res.status(200).json(checks);
}
