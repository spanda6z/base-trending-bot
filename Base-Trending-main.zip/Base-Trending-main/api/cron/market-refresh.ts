import type { VercelRequest, VercelResponse } from "@vercel/node";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (
    process.env.CRON_SECRET &&
    req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`
  ) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  console.log("[cron] market-refresh started");
  // TODO: Phase 3 — DexScreener + trending score recalculation

  return res.status(200).json({ ok: true, job: "market-refresh" });
}
