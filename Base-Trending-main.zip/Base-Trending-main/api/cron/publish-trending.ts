import type { VercelRequest, VercelResponse } from "@vercel/node";
import { publishTrendingToChannel } from "../../src/services/publishing";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (
    process.env.CRON_SECRET &&
    req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`
  ) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  try {
    const result = await publishTrendingToChannel();
    console.log("[cron:publish]", result);
    return res.status(200).json({ ok: true, job: "publish-trending", ...result });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ ok: false, error: err.message });
  }
}
