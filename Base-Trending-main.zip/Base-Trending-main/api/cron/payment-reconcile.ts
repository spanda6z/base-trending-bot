import type { VercelRequest, VercelResponse } from "@vercel/node";
import { expireOldInvoices } from "../../src/services/payment";
import { runPaymentScanner } from "../../src/services/paymentScanner";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (
    process.env.CRON_SECRET &&
    req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`
  ) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const started = Date.now();

  try {
    await expireOldInvoices();
    const report = await runPaymentScanner();
    const durationMs = Date.now() - started;

    console.log(
      `[cron:payment-reconcile] blocks ${report.fromBlock}→${report.toBlock} | ` +
        `pending=${report.pendingInvoices} eth=${report.ethMatches} usdc=${report.usdcMatches} ` +
        `settled=${report.settled} finalized=${report.finalized} (${durationMs}ms)`
    );

    if (report.errors.length) {
      console.warn("[cron:payment-reconcile] errors:", report.errors);
    }

    return res.status(200).json({
      ok: true,
      job: "payment-reconcile",
      durationMs,
      ...report,
    });
  } catch (err: any) {
    console.error("[cron:payment-reconcile] failed:", err);
    return res.status(500).json({
      ok: false,
      error: err.message || "Scanner failed",
    });
  }
}
