import type { VercelRequest, VercelResponse } from "@vercel/node";
import { expirePromotions } from "../../src/services/publishing";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (
    process.env.CRON_SECRET &&
    req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`
  ) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  try {
    const count = await expirePromotions();
    console.log("[cron:promotion-expire] expired", count);
    return res.status(200).json({ ok: true, job: "promotion-expire", expired: count });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ ok: false, error: err.message });
  }
}
