import {
  pgTable,
  serial,
  text,
  varchar,
  integer,
  bigint,
  boolean,
  timestamp,
  jsonb,
  numeric,
  uniqueIndex,
  index,
  primaryKey,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// ============================================
// USERS
// ============================================
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    telegramId: bigint("telegram_id", { mode: "number" }).notNull().unique(),
    username: varchar("username", { length: 255 }),
    firstName: varchar("first_name", { length: 255 }),
    lastName: varchar("last_name", { length: 255 }),
    isBlocked: boolean("is_blocked").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => [index("users_telegram_id_idx").on(t.telegramId)]
);

// ============================================
// TOKENS
// ============================================
export const tokens = pgTable(
  "tokens",
  {
    id: serial("id").primaryKey(),
    address: varchar("address", { length: 42 }).notNull().unique(),
    name: varchar("name", { length: 255 }),
    symbol: varchar("symbol", { length: 64 }),
    decimals: integer("decimals"),
    totalSupply: text("total_supply"),
    isVerified: boolean("is_verified").default(false).notNull(),
    isSpam: boolean("is_spam").default(false).notNull(),
    flags: jsonb("flags").$type<Record<string, unknown>>().default({}),
    firstSeenAt: timestamp("first_seen_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => [index("tokens_address_idx").on(t.address)]
);

// ============================================
// TRADING PAIRS
// ============================================
export const tradingPairs = pgTable(
  "trading_pairs",
  {
    id: serial("id").primaryKey(),
    pairAddress: varchar("pair_address", { length: 42 }).notNull().unique(),
    token0Address: varchar("token0_address", { length: 42 }).notNull(),
    token1Address: varchar("token1_address", { length: 42 }).notNull(),
    factoryAddress: varchar("factory_address", { length: 42 }).notNull(),
    dex: varchar("dex", { length: 64 }).notNull(),
    createdBlock: bigint("created_block", { mode: "number" }),
    createdTx: varchar("created_tx", { length: 66 }),
    createdAt: timestamp("created_at"),
    isActive: boolean("is_active").default(true).notNull(),
    firstSeenAt: timestamp("first_seen_at").defaultNow().notNull(),
  },
  (t) => [
    index("pairs_factory_idx").on(t.factoryAddress),
    index("pairs_token0_idx").on(t.token0Address),
    index("pairs_token1_idx").on(t.token1Address),
  ]
);

// ============================================
// INDEXER CURSORS
// ============================================
export const indexerCursors = pgTable("indexer_cursors", {
  factoryAddress: varchar("factory_address", { length: 42 }).primaryKey(),
  lastProcessedBlock: bigint("last_processed_block", { mode: "number" }).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ============================================
// MARKET SNAPSHOTS
// ============================================
export const marketSnapshots = pgTable(
  "market_snapshots",
  {
    id: serial("id").primaryKey(),
    tokenId: integer("token_id").notNull().references(() => tokens.id),
    pairAddress: varchar("pair_address", { length: 42 }),
    priceUsd: numeric("price_usd", { precision: 36, scale: 18 }),
    volume24h: numeric("volume_24h", { precision: 36, scale: 2 }),
    liquidityUsd: numeric("liquidity_usd", { precision: 36, scale: 2 }),
    buys24h: integer("buys_24h"),
    sells24h: integer("sells_24h"),
    priceChange1h: numeric("price_change_1h", { precision: 10, scale: 4 }),
    priceChange24h: numeric("price_change_24h", { precision: 10, scale: 4 }),
    dex: varchar("dex", { length: 64 }),
    snapshotAt: timestamp("snapshot_at").defaultNow().notNull(),
  },
  (t) => [
    index("snapshots_token_idx").on(t.tokenId),
    index("snapshots_time_idx").on(t.snapshotAt),
  ]
);

// ============================================
// TRENDING SCORES (Organic only)
// ============================================
export const trendingScores = pgTable(
  "trending_scores",
  {
    id: serial("id").primaryKey(),
    tokenId: integer("token_id").notNull().references(() => tokens.id),
    score: numeric("score", { precision: 18, scale: 8 }).notNull(),
    rank: integer("rank"),
    volumeScore: numeric("volume_score", { precision: 18, scale: 8 }),
    liquidityScore: numeric("liquidity_score", { precision: 18, scale: 8 }),
    activityScore: numeric("activity_score", { precision: 18, scale: 8 }),
    momentum1hScore: numeric("momentum_1h_score", { precision: 18, scale: 8 }),
    momentum24hScore: numeric("momentum_24h_score", { precision: 18, scale: 8 }),
    calculatedAt: timestamp("calculated_at").defaultNow().notNull(),
    version: integer("version").default(1).notNull(),
  },
  (t) => [
    index("trending_rank_idx").on(t.rank),
    index("trending_token_idx").on(t.tokenId),
  ]
);

// ============================================
// PROMOTION PACKAGES
// ============================================
export const promotionPackages = pgTable("promotion_packages", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  durationHours: integer("duration_hours").notNull(),
  priceUsdCents: integer("price_usd_cents").notNull(),
  maxConcurrent: integer("max_concurrent").notNull().default(1),
  isActive: boolean("is_active").default(true).notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================
// PROMOTION SESSIONS (state machine)
// ============================================
export const promotionSessions = pgTable(
  "promotion_sessions",
  {
    id: serial("id").primaryKey(),
    sessionKey: varchar("session_key", { length: 64 }).notNull().unique(),
    userId: integer("user_id").notNull().references(() => users.id),
    telegramId: bigint("telegram_id", { mode: "number" }).notNull(),
    step: varchar("step", { length: 64 }).notNull().default("MAIN_MENU"),
    packageCode: varchar("package_code", { length: 32 }),
    durationHours: integer("duration_hours"),
    priceUsdCents: integer("price_usd_cents"),
    tokenAddress: varchar("token_address", { length: 42 }),
    tokenName: varchar("token_name", { length: 255 }),
    tokenSymbol: varchar("token_symbol", { length: 64 }),
    telegramLink: text("telegram_link"),
    xLink: text("x_link"),
    websiteLink: text("website_link"),
    status: varchar("status", { length: 32 }).notNull().default("ACTIVE"),
    expiresAt: timestamp("expires_at"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => [
    index("sessions_user_idx").on(t.userId),
    index("sessions_telegram_idx").on(t.telegramId),
    index("sessions_status_idx").on(t.status),
  ]
);

// ============================================
// INVOICES
// ============================================
export const invoices = pgTable(
  "invoices",
  {
    id: serial("id").primaryKey(),
    invoiceId: varchar("invoice_id", { length: 64 }).notNull().unique(),
    sessionId: integer("session_id").notNull().references(() => promotionSessions.id),
    userId: integer("user_id").notNull().references(() => users.id),
    amountUsdCents: integer("amount_usd_cents").notNull(),
    currency: varchar("currency", { length: 8 }).notNull(),
    expectedAmount: text("expected_amount").notNull(),
    treasuryAddress: varchar("treasury_address", { length: 42 }).notNull(),
    status: varchar("status", { length: 32 }).notNull().default("AWAITING_PAYMENT"),
    paymentTxHash: varchar("payment_tx_hash", { length: 66 }),
    expiresAt: timestamp("expires_at").notNull(),
    paidAt: timestamp("paid_at"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => [
    index("invoices_status_idx").on(t.status),
    index("invoices_user_idx").on(t.userId),
  ]
);

// ============================================
// PAYMENTS
// ============================================
export const payments = pgTable(
  "payments",
  {
    id: serial("id").primaryKey(),
    invoiceId: integer("invoice_id").notNull().references(() => invoices.id),
    txHash: varchar("tx_hash", { length: 66 }).notNull().unique(),
    fromAddress: varchar("from_address", { length: 42 }),
    amount: text("amount").notNull(),
    currency: varchar("currency", { length: 8 }).notNull(),
    blockNumber: bigint("block_number", { mode: "number" }),
    confirmations: integer("confirmations").default(0),
    confirmedAt: timestamp("confirmed_at"),
    rawLog: jsonb("raw_log"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("payments_tx_idx").on(t.txHash)]
);

// ============================================
// RECEIPTS
// ============================================
export const receipts = pgTable("receipts", {
  id: serial("id").primaryKey(),
  receiptId: varchar("receipt_id", { length: 64 }).notNull().unique(),
  invoiceId: integer("invoice_id").notNull().references(() => invoices.id).unique(),
  userId: integer("user_id").notNull().references(() => users.id),
  telegramId: bigint("telegram_id", { mode: "number" }).notNull(),
  tokenName: varchar("token_name", { length: 255 }),
  tokenSymbol: varchar("token_symbol", { length: 64 }),
  tokenAddress: varchar("token_address", { length: 42 }),
  packageCode: varchar("package_code", { length: 32 }),
  durationHours: integer("duration_hours"),
  amountUsdCents: integer("amount_usd_cents"),
  paymentCurrency: varchar("payment_currency", { length: 8 }),
  paymentAmount: text("payment_amount"),
  txHash: varchar("tx_hash", { length: 66 }),
  treasuryAddress: varchar("treasury_address", { length: 42 }),
  promotionStartsAt: timestamp("promotion_starts_at"),
  promotionEndsAt: timestamp("promotion_ends_at"),
  snapshot: jsonb("snapshot"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================
// PROMOTIONS
// ============================================
export const promotions = pgTable(
  "promotions",
  {
    id: serial("id").primaryKey(),
    sessionId: integer("session_id").references(() => promotionSessions.id),
    invoiceId: integer("invoice_id").references(() => invoices.id),
    receiptId: integer("receipt_id").references(() => receipts.id),
    userId: integer("user_id").notNull().references(() => users.id),
    tokenId: integer("token_id").references(() => tokens.id),
    tokenAddress: varchar("token_address", { length: 42 }).notNull(),
    packageCode: varchar("package_code", { length: 32 }).notNull(),
    durationHours: integer("duration_hours").notNull(),
    startsAt: timestamp("starts_at").notNull(),
    endsAt: timestamp("ends_at").notNull(),
    status: varchar("status", { length: 32 }).notNull().default("PENDING"),
    telegramLink: text("telegram_link"),
    xLink: text("x_link"),
    websiteLink: text("website_link"),
    publishedMessageId: bigint("published_message_id", { mode: "number" }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => [
    index("promotions_status_idx").on(t.status),
    index("promotions_package_idx").on(t.packageCode),
    index("promotions_ends_at_idx").on(t.endsAt),
  ]
);

// ============================================
// PROMOTION SLOTS
// ============================================
export const promotionSlots = pgTable("promotion_slots", {
  packageCode: varchar("package_code", { length: 32 }).primaryKey(),
  maxConcurrent: integer("max_concurrent").notNull(),
  currentActive: integer("current_active").default(0).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ============================================
// TELEGRAM CHANNELS
// ============================================
export const telegramChannels = pgTable("telegram_channels", {
  id: serial("id").primaryKey(),
  channelId: varchar("channel_id", { length: 64 }).notNull().unique(),
  title: varchar("title", { length: 255 }),
  type: varchar("type", { length: 32 }).notNull().default("trending"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================
// PUBLISHED POSTS
// ============================================
export const publishedPosts = pgTable(
  "published_posts",
  {
    id: serial("id").primaryKey(),
    channelId: varchar("channel_id", { length: 64 }).notNull(),
    messageId: bigint("message_id", { mode: "number" }),
    postType: varchar("post_type", { length: 32 }).notNull(),
    contentHash: varchar("content_hash", { length: 64 }),
    relatedPromotionId: integer("related_promotion_id"),
    publishedAt: timestamp("published_at").defaultNow().notNull(),
  },
  (t) => [index("posts_hash_idx").on(t.contentHash)]
);

// ============================================
// ADMIN USERS
// ============================================
export const adminUsers = pgTable("admin_users", {
  telegramId: bigint("telegram_id", { mode: "number" }).primaryKey(),
  role: varchar("role", { length: 32 }).default("admin").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================
// ADMIN AUDIT LOGS
// ============================================
export const adminAuditLogs = pgTable("admin_audit_logs", {
  id: serial("id").primaryKey(),
  actorTelegramId: bigint("actor_telegram_id", { mode: "number" }).notNull(),
  action: varchar("action", { length: 128 }).notNull(),
  targetType: varchar("target_type", { length: 64 }),
  targetId: varchar("target_id", { length: 128 }),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================
// BACKGROUND JOBS
// ============================================
export const backgroundJobs = pgTable(
  "background_jobs",
  {
    id: serial("id").primaryKey(),
    jobKey: varchar("job_key", { length: 128 }).notNull().unique(),
    type: varchar("type", { length: 64 }).notNull(),
    status: varchar("status", { length: 32 }).notNull().default("PENDING"),
    payload: jsonb("payload"),
    attempts: integer("attempts").default(0).notNull(),
    maxAttempts: integer("max_attempts").default(5).notNull(),
    lastError: text("last_error"),
    scheduledAt: timestamp("scheduled_at"),
    startedAt: timestamp("started_at"),
    completedAt: timestamp("completed_at"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("jobs_status_idx").on(t.status), index("jobs_type_idx").on(t.type)]
);

// ============================================
// SYSTEM SETTINGS
// ============================================
export const systemSettings = pgTable("system_settings", {
  key: varchar("key", { length: 128 }).primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ============================================
// RELATIONS
// ============================================
export const usersRelations = relations(users, ({ many }) => ({
  sessions: many(promotionSessions),
  invoices: many(invoices),
  promotions: many(promotions),
}));

export const tokensRelations = relations(tokens, ({ many }) => ({
  snapshots: many(marketSnapshots),
  scores: many(trendingScores),
}));
