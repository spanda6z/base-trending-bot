import { Markup } from "telegraf";
import { PACKAGE_LABELS, PACKAGE_PRICES } from "../lib/config";
import { formatUsd as moneyFormat } from "../lib/money";

type InlineKeyboard = ReturnType<typeof Markup.inlineKeyboard>;

export function mainMenuKeyboard(): InlineKeyboard {
  return Markup.inlineKeyboard([
    [Markup.button.callback("🚀 BUY TRENDING", "buy_trending")],
    [
      Markup.button.callback("📊 TRENDING NOW", "trending_now"),
      Markup.button.callback("🆕 NEW PAIRS", "new_pairs"),
    ],
    [
      Markup.button.callback("🔍 SEARCH TOKEN", "search_token"),
      Markup.button.callback("💎 PROMOTIONS", "my_promotions"),
    ],
    [Markup.button.callback("❓ HELP", "help")],
  ]);
}

export function packageSelectKeyboard(): InlineKeyboard {
  return Markup.inlineKeyboard([
    [Markup.button.callback(PACKAGE_LABELS.TOP1, "pkg_TOP1")],
    [Markup.button.callback(PACKAGE_LABELS.TOP5, "pkg_TOP5")],
    [Markup.button.callback(PACKAGE_LABELS.TOP10, "pkg_TOP10")],
    [Markup.button.callback("« Back", "main_menu")],
  ]);
}

export function durationKeyboard(packageCode: "TOP1" | "TOP5" | "TOP10"): InlineKeyboard {
  const prices = PACKAGE_PRICES[packageCode];
  return Markup.inlineKeyboard([
    [
      Markup.button.callback(
        `3 HOURS — ${moneyFormat(prices[3])}`,
        `dur_${packageCode}_3`
      ),
    ],
    [
      Markup.button.callback(
        `6 HOURS — ${moneyFormat(prices[6])}`,
        `dur_${packageCode}_6`
      ),
    ],
    [
      Markup.button.callback(
        `12 HOURS — ${moneyFormat(prices[12])}`,
        `dur_${packageCode}_12`
      ),
    ],
    [Markup.button.callback("« Back", "buy_trending")],
  ]);
}

export function confirmTokenKeyboard(): InlineKeyboard {
  return Markup.inlineKeyboard([
    [
      Markup.button.callback("✅ CONFIRM TOKEN", "confirm_token"),
      Markup.button.callback("❌ CANCEL", "cancel_session"),
    ],
  ]);
}

export function skipCancelKeyboard(nextAction: string): InlineKeyboard {
  return Markup.inlineKeyboard([
    [
      Markup.button.callback("SKIP", nextAction),
      Markup.button.callback("CANCEL", "cancel_session"),
    ],
  ]);
}

export function orderReviewKeyboard(): InlineKeyboard {
  return Markup.inlineKeyboard([
    [Markup.button.callback("✅ CONFIRM & PAY", "confirm_pay")],
    [Markup.button.callback("✏️ EDIT DETAILS", "edit_order")],
    [Markup.button.callback("❌ CANCEL ORDER", "cancel_session")],
  ]);
}

export function currencyKeyboard(): InlineKeyboard {
  return Markup.inlineKeyboard([
    [
      Markup.button.callback("ETH", "pay_ETH"),
      Markup.button.callback("USDC", "pay_USDC"),
    ],
    [Markup.button.callback("❌ CANCEL", "cancel_session")],
  ]);
}

export function backToMenuKeyboard(): InlineKeyboard {
  return Markup.inlineKeyboard([
    [Markup.button.callback("« Main Menu", "main_menu")],
  ]);
}
