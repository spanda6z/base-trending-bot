import { Telegraf, Context } from "telegraf";
import { env } from "../lib/config";

export interface BotContext extends Context {}

let botInstance: Telegraf<BotContext> | null = null;

export function getBot(): Telegraf<BotContext> {
  if (!botInstance) {
    if (!env.TELEGRAM_BOT_TOKEN) {
      throw new Error("TELEGRAM_BOT_TOKEN is required");
    }
    botInstance = new Telegraf<BotContext>(env.TELEGRAM_BOT_TOKEN);
  }
  return botInstance;
}

export function isAdmin(telegramId: number): boolean {
  const admins = (env.TELEGRAM_ADMIN_IDS || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .map(Number);
  return admins.includes(telegramId);
}
