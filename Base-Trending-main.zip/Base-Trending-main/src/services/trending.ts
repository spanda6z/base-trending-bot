import { desc, eq } from "drizzle-orm";
import { db } from "../db";
import { tokens, trendingScores, promotions } from "../db/schema";

export function calculateScore(metrics: {
  volume24h: number;
  liquidity: number;
  buys: number;
  sells: number;
  change1h: number;
  change24h: number;
}): number {
  const vol = Math.log10(Math.max(metrics.volume24h, 1));
  const liq = Math.log10(Math.max(metrics.liquidity, 1));
  const activity = Math.min(metrics.buys + metrics.sells, 500) / 500;
  const mom1h = Math.max(Math.min(metrics.change1h / 50, 1), -1);
  const mom24h = Math.max(Math.min(metrics.change24h / 100, 1), -1);

  const score =
    vol * 0.3 +
    liq * 0.25 +
    activity * 0.2 +
    (mom1h + 1) * 0.075 +
    (mom24h + 1) * 0.05;

  return Number(score.toFixed(8));
}

export async function getOrganicTop(limit = 10) {
  const scores = await db
    .select({
      score: trendingScores.score,
      rank: trendingScores.rank,
      tokenId: trendingScores.tokenId,
      address: tokens.address,
      name: tokens.name,
      symbol: tokens.symbol,
    })
    .from(trendingScores)
    .innerJoin(tokens, eq(trendingScores.tokenId, tokens.id))
    .where(eq(tokens.isSpam, false))
    .orderBy(desc(trendingScores.score))
    .limit(limit);

  return scores;
}

export async function getActiveSponsored() {
  return db
    .select()
    .from(promotions)
    .where(eq(promotions.status, "ACTIVE"))
    .orderBy(desc(promotions.startsAt));
}

export function formatOrganicMessage(
  items: Awaited<ReturnType<typeof getOrganicTop>>
): string {
  if (!items.length) {
    return "🚀 *BASE NETWORK TRENDING*\n\nNo data yet. Check back soon.";
  }

  const lines = [
    `🚀 *BASE NETWORK TRENDING*`,
    `Updated: ${new Date().toUTCString()}`,
    ``,
  ];

  items.forEach((item, i) => {
    lines.push(
      `*#${i + 1}* ${item.name || "Unknown"} ($${item.symbol || "???"})`,
      `Contract: \`${item.address}\``,
      ``
    );
  });

  lines.push(`_Organic rankings only. Sponsored placements are listed separately._`);
  return lines.join("\n");
}

export function formatSponsoredMessage(
  promos: Awaited<ReturnType<typeof getActiveSponsored>>
): string {
  if (!promos.length) return "";

  const lines = [`🔥 *SPONSORED TRENDING*`, ``];

  for (const p of promos) {
    lines.push(
      `*${p.packageCode}* — ${p.tokenAddress.slice(0, 10)}…`,
      `Until ${p.endsAt.toUTCString()}`,
      p.websiteLink ? `Website: ${p.websiteLink}` : "",
      p.telegramLink ? `Telegram: ${p.telegramLink}` : "",
      ``
    );
  }

  lines.push(`_All of the above are paid SPONSORED placements._`);
  return lines.join("\n");
}
