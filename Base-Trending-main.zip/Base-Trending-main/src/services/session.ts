import { eq, and } from "drizzle-orm";
import { nanoid } from "nanoid";
import { db } from "../db";
import { users, promotionSessions } from "../db/schema";
import { env } from "../lib/config";

export async function ensureUser(telegramId: number, profile?: {
  username?: string;
  firstName?: string;
  lastName?: string;
}) {
  const existing = await db.query.users.findFirst({
    where: eq(users.telegramId, telegramId),
  });
  if (existing) return existing;

  const [created] = await db
    .insert(users)
    .values({
      telegramId,
      username: profile?.username,
      firstName: profile?.firstName,
      lastName: profile?.lastName,
    })
    .returning();
  return created;
}

export async function getActiveSession(telegramId: number) {
  return db.query.promotionSessions.findFirst({
    where: and(
      eq(promotionSessions.telegramId, telegramId),
      eq(promotionSessions.status, "ACTIVE")
    ),
    orderBy: (s, { desc }) => [desc(s.createdAt)],
  });
}

export async function createSession(telegramId: number, userId: number) {
  await db
    .update(promotionSessions)
    .set({ status: "CANCELLED", updatedAt: new Date() })
    .where(
      and(
        eq(promotionSessions.telegramId, telegramId),
        eq(promotionSessions.status, "ACTIVE")
      )
    );

  const expiresAt = new Date(
    Date.now() + (env.SESSION_EXPIRY_MINUTES || 60) * 60 * 1000
  );

  const [session] = await db
    .insert(promotionSessions)
    .values({
      sessionKey: nanoid(16),
      userId,
      telegramId,
      step: "SELECT_PACKAGE",
      status: "ACTIVE",
      expiresAt,
    })
    .returning();
  return session;
}

export async function updateSession(
  sessionId: number,
  data: Partial<{
    step: string;
    packageCode: string;
    durationHours: number;
    priceUsdCents: number;
    tokenAddress: string;
    tokenName: string;
    tokenSymbol: string;
    telegramLink: string | null;
    xLink: string | null;
    websiteLink: string | null;
    status: string;
  }>
) {
  const [updated] = await db
    .update(promotionSessions)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(promotionSessions.id, sessionId))
    .returning();
  return updated;
}

export async function cancelSession(sessionId: number) {
  return updateSession(sessionId, { status: "CANCELLED", step: "CANCELLED" });
}
