/**
 * Safe money handling — never use floating point for settlement.
 */

export function usdCentsToDisplay(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

export function formatUsd(cents: number): string {
  return usdCentsToDisplay(cents);
}

/** Convert USD cents to ETH wei given current price. */
export function usdCentsToEthWei(
  usdCents: number,
  ethPriceUsd: string
): bigint {
  const price = BigInt(Math.round(parseFloat(ethPriceUsd) * 1e8));
  const wei = (BigInt(usdCents) * 10n ** 16n) / price;
  return wei;
}

/** Convert USD cents to USDC base units (6 decimals). */
export function usdCentsToUsdc(usdCents: number): bigint {
  return BigInt(usdCents) * 10_000n;
}

export function usdcToDisplay(baseUnits: bigint): string {
  const whole = baseUnits / 1_000_000n;
  const frac = (baseUnits % 1_000_000n).toString().padStart(6, "0").slice(0, 2);
  return `${whole}.${frac}`;
}

export function ethWeiToDisplay(wei: bigint): string {
  const eth = Number(wei) / 1e18;
  return eth.toFixed(6);
}
