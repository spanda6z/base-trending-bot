import {
  createPublicClient,
  http,
  type PublicClient,
  type Chain,
} from "viem";
import { base } from "viem/chains";
import { env } from "./config";

export const baseChain: Chain = {
  ...base,
  id: 8453,
};

let client: PublicClient | null = null;

export function getPublicClient(): PublicClient {
  if (!client) {
    client = createPublicClient({
      chain: baseChain,
      transport: http(env.BASE_RPC_URL, {
        retryCount: 3,
        retryDelay: 1000,
        timeout: 20_000,
      }),
    });
  }
  return client;
}

export const USDC_ADDRESS = env.BASE_USDC_ADDRESS as `0x${string}`;
export const TREASURY_ADDRESS = env.BASE_TREASURY_ADDRESS as `0x${string}`;

export const ERC20_ABI = [
  {
    type: "function",
    name: "name",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "string" }],
  },
  {
    type: "function",
    name: "symbol",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "string" }],
  },
  {
    type: "function",
    name: "decimals",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "uint8" }],
  },
  {
    type: "function",
    name: "totalSupply",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "uint256" }],
  },
  {
    type: "event",
    name: "Transfer",
    inputs: [
      { name: "from", type: "address", indexed: true },
      { name: "to", type: "address", indexed: true },
      { name: "value", type: "uint256", indexed: false },
    ],
  },
] as const;
