import { z } from "zod";

const envSchema = z.object({
  TELEGRAM_BOT_TOKEN: z.string().min(1),
  TELEGRAM_WEBHOOK_SECRET: z.string().min(16),
  TELEGRAM_CHANNEL_ID: z.string().optional(),
  TELEGRAM_ADMIN_IDS: z.string().optional(),

  BASE_RPC_URL: z.string().url(),
  BASE_CHAIN_ID: z.coerce.number().default(8453),
  BASE_TREASURY_ADDRESS: z
    .string()
    .regex(/^0x[a-fA-F0-9]{40}$/)
    .default("0x1Dad4D6B65dA80CEB7c6937B264132eDD21Dd39E"),
  BASE_USDC_ADDRESS: z
    .string()
    .regex(/^0x[a-fA-F0-9]{40}$/)
    .default("0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"),

  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().optional(),

  APP_BASE_URL: z.string().url().optional(),
  CRON_SECRET: z.string().min(16).optional(),

  DEXSCREENER_API_URL: z
    .string()
    .url()
    .default("https://api.dexscreener.com/latest/dex"),

  PROMOTION_PAYMENT_CONFIRMATIONS: z.coerce.number().default(3),
  INVOICE_EXPIRY_MINUTES: z.coerce.number().default(30),
  PUBLISH_INTERVAL_MINUTES: z.coerce.number().default(15),
  SESSION_EXPIRY_MINUTES: z.coerce.number().default(60),

  AERODROME_POOL_FACTORY: z
    .string()
    .default("0x420DD381b31aEf6683db6B902084cB0FFECe40Da"),
  AERODROME_CL_FACTORY: z
    .string()
    .default("0xf8f2eB4940CFE7d13603DDDD87f123820Fc061Ef"),
  UNISWAP_V2_FACTORY: z
    .string()
    .default("0x8909Dc15e40173Ff4699343b6eB8132c65e18eC6"),
  UNISWAP_V3_FACTORY: z
    .string()
    .default("0x33128a8fC17869897dcE68Ed026d694621f6FDfD"),
});

export type Env = z.infer<typeof envSchema>;

function loadEnv(): Env {
  const parsed = envSchema.safeParse(process.env);
  if (!parsed.success) {
    console.error("Invalid environment variables:", parsed.error.flatten());
    return process.env as unknown as Env;
  }
  return parsed.data;
}

export const env = loadEnv();

export const PACKAGE_PRICES = {
  TOP1: {
    3: 500_00,
    6: 800_00,
    12: 1500_00,
  },
  TOP5: {
    3: 150_00,
    6: 250_00,
    12: 400_00,
  },
  TOP10: {
    3: 100_00,
    6: 150_00,
    12: 250_00,
  },
} as const;

export const PACKAGE_LABELS = {
  TOP1: "🥇 TOP 1 TRENDING",
  TOP5: "🔥 TOP 5 TRENDING",
  TOP10: "📈 TOP 10 TRENDING",
} as const;

export const MAX_CONCURRENT = {
  TOP1: 1,
  TOP5: 5,
  TOP10: 10,
} as const;
