import { db } from "../src/db";
import { promotionPackages, promotionSlots } from "../src/db/schema";
import { PACKAGE_PRICES, MAX_CONCURRENT } from "../src/lib/config";

async function seed() {
  console.log("Seeding packages…");

  const packages = [
    { code: "TOP1", name: "TOP 1 TRENDING", hours: [3, 6, 12] as const },
    { code: "TOP5", name: "TOP 5 TRENDING", hours: [3, 6, 12] as const },
    { code: "TOP10", name: "TOP 10 TRENDING", hours: [3, 6, 12] as const },
  ];

  for (const pkg of packages) {
    for (const h of pkg.hours) {
      const price =
        PACKAGE_PRICES[pkg.code as keyof typeof PACKAGE_PRICES][h];
      await db
        .insert(promotionPackages)
        .values({
          code: `${pkg.code}_${h}H`,
          name: `${pkg.name} ${h}h`,
          durationHours: h,
          priceUsdCents: price,
          maxConcurrent:
            MAX_CONCURRENT[pkg.code as keyof typeof MAX_CONCURRENT],
          isActive: true,
        })
        .onConflictDoNothing();
    }

    await db
      .insert(promotionSlots)
      .values({
        packageCode: pkg.code,
        maxConcurrent:
          MAX_CONCURRENT[pkg.code as keyof typeof MAX_CONCURRENT],
        currentActive: 0,
      })
      .onConflictDoNothing();
  }

  console.log("Seed complete.");
  process.exit(0);
}

seed().catch((e) => {
  console.error(e);
  process.exit(1);
});
