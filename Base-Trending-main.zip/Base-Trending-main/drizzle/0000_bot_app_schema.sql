CREATE TABLE "admin_audit_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"actor_telegram_id" bigint NOT NULL,
	"action" varchar(128) NOT NULL,
	"target_type" varchar(64),
	"target_id" varchar(128),
	"metadata" jsonb,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "admin_users" (
	"telegram_id" bigint PRIMARY KEY NOT NULL,
	"role" varchar(32) DEFAULT 'admin' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "background_jobs" (
	"id" serial PRIMARY KEY NOT NULL,
	"job_key" varchar(128) NOT NULL,
	"type" varchar(64) NOT NULL,
	"status" varchar(32) DEFAULT 'PENDING' NOT NULL,
	"payload" jsonb,
	"attempts" integer DEFAULT 0 NOT NULL,
	"max_attempts" integer DEFAULT 5 NOT NULL,
	"last_error" text,
	"scheduled_at" timestamp,
	"started_at" timestamp,
	"completed_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "background_jobs_job_key_unique" UNIQUE("job_key")
);
--> statement-breakpoint
CREATE TABLE "indexer_cursors" (
	"factory_address" varchar(42) PRIMARY KEY NOT NULL,
	"last_processed_block" bigint NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "invoices" (
	"id" serial PRIMARY KEY NOT NULL,
	"invoice_id" varchar(64) NOT NULL,
	"session_id" integer NOT NULL,
	"user_id" integer NOT NULL,
	"amount_usd_cents" integer NOT NULL,
	"currency" varchar(8) NOT NULL,
	"expected_amount" text NOT NULL,
	"treasury_address" varchar(42) NOT NULL,
	"status" varchar(32) DEFAULT 'AWAITING_PAYMENT' NOT NULL,
	"payment_tx_hash" varchar(66),
	"expires_at" timestamp NOT NULL,
	"paid_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "invoices_invoice_id_unique" UNIQUE("invoice_id")
);
--> statement-breakpoint
CREATE TABLE "market_snapshots" (
	"id" serial PRIMARY KEY NOT NULL,
	"token_id" integer NOT NULL,
	"pair_address" varchar(42),
	"price_usd" numeric(36, 18),
	"volume_24h" numeric(36, 2),
	"liquidity_usd" numeric(36, 2),
	"buys_24h" integer,
	"sells_24h" integer,
	"price_change_1h" numeric(10, 4),
	"price_change_24h" numeric(10, 4),
	"dex" varchar(64),
	"snapshot_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payments" (
	"id" serial PRIMARY KEY NOT NULL,
	"invoice_id" integer NOT NULL,
	"tx_hash" varchar(66) NOT NULL,
	"from_address" varchar(42),
	"amount" text NOT NULL,
	"currency" varchar(8) NOT NULL,
	"block_number" bigint,
	"confirmations" integer DEFAULT 0,
	"confirmed_at" timestamp,
	"raw_log" jsonb,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "payments_tx_hash_unique" UNIQUE("tx_hash")
);
--> statement-breakpoint
CREATE TABLE "promotion_packages" (
	"id" serial PRIMARY KEY NOT NULL,
	"code" varchar(32) NOT NULL,
	"name" varchar(128) NOT NULL,
	"duration_hours" integer NOT NULL,
	"price_usd_cents" integer NOT NULL,
	"max_concurrent" integer DEFAULT 1 NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "promotion_packages_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "promotion_sessions" (
	"id" serial PRIMARY KEY NOT NULL,
	"session_key" varchar(64) NOT NULL,
	"user_id" integer NOT NULL,
	"telegram_id" bigint NOT NULL,
	"step" varchar(64) DEFAULT 'MAIN_MENU' NOT NULL,
	"package_code" varchar(32),
	"duration_hours" integer,
	"price_usd_cents" integer,
	"token_address" varchar(42),
	"token_name" varchar(255),
	"token_symbol" varchar(64),
	"telegram_link" text,
	"x_link" text,
	"website_link" text,
	"status" varchar(32) DEFAULT 'ACTIVE' NOT NULL,
	"expires_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "promotion_sessions_session_key_unique" UNIQUE("session_key")
);
--> statement-breakpoint
CREATE TABLE "promotion_slots" (
	"package_code" varchar(32) PRIMARY KEY NOT NULL,
	"max_concurrent" integer NOT NULL,
	"current_active" integer DEFAULT 0 NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "promotions" (
	"id" serial PRIMARY KEY NOT NULL,
	"session_id" integer,
	"invoice_id" integer,
	"receipt_id" integer,
	"user_id" integer NOT NULL,
	"token_id" integer,
	"token_address" varchar(42) NOT NULL,
	"package_code" varchar(32) NOT NULL,
	"duration_hours" integer NOT NULL,
	"starts_at" timestamp NOT NULL,
	"ends_at" timestamp NOT NULL,
	"status" varchar(32) DEFAULT 'PENDING' NOT NULL,
	"telegram_link" text,
	"x_link" text,
	"website_link" text,
	"published_message_id" bigint,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "published_posts" (
	"id" serial PRIMARY KEY NOT NULL,
	"channel_id" varchar(64) NOT NULL,
	"message_id" bigint,
	"post_type" varchar(32) NOT NULL,
	"content_hash" varchar(64),
	"related_promotion_id" integer,
	"published_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "receipts" (
	"id" serial PRIMARY KEY NOT NULL,
	"receipt_id" varchar(64) NOT NULL,
	"invoice_id" integer NOT NULL,
	"user_id" integer NOT NULL,
	"telegram_id" bigint NOT NULL,
	"token_name" varchar(255),
	"token_symbol" varchar(64),
	"token_address" varchar(42),
	"package_code" varchar(32),
	"duration_hours" integer,
	"amount_usd_cents" integer,
	"payment_currency" varchar(8),
	"payment_amount" text,
	"tx_hash" varchar(66),
	"treasury_address" varchar(42),
	"promotion_starts_at" timestamp,
	"promotion_ends_at" timestamp,
	"snapshot" jsonb,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "receipts_receipt_id_unique" UNIQUE("receipt_id"),
	CONSTRAINT "receipts_invoice_id_unique" UNIQUE("invoice_id")
);
--> statement-breakpoint
CREATE TABLE "system_settings" (
	"key" varchar(128) PRIMARY KEY NOT NULL,
	"value" jsonb NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "telegram_channels" (
	"id" serial PRIMARY KEY NOT NULL,
	"channel_id" varchar(64) NOT NULL,
	"title" varchar(255),
	"type" varchar(32) DEFAULT 'trending' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "telegram_channels_channel_id_unique" UNIQUE("channel_id")
);
--> statement-breakpoint
CREATE TABLE "tokens" (
	"id" serial PRIMARY KEY NOT NULL,
	"address" varchar(42) NOT NULL,
	"name" varchar(255),
	"symbol" varchar(64),
	"decimals" integer,
	"total_supply" text,
	"is_verified" boolean DEFAULT false NOT NULL,
	"is_spam" boolean DEFAULT false NOT NULL,
	"flags" jsonb DEFAULT '{}'::jsonb,
	"first_seen_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "tokens_address_unique" UNIQUE("address")
);
--> statement-breakpoint
CREATE TABLE "trading_pairs" (
	"id" serial PRIMARY KEY NOT NULL,
	"pair_address" varchar(42) NOT NULL,
	"token0_address" varchar(42) NOT NULL,
	"token1_address" varchar(42) NOT NULL,
	"factory_address" varchar(42) NOT NULL,
	"dex" varchar(64) NOT NULL,
	"created_block" bigint,
	"created_tx" varchar(66),
	"created_at" timestamp,
	"is_active" boolean DEFAULT true NOT NULL,
	"first_seen_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "trading_pairs_pair_address_unique" UNIQUE("pair_address")
);
--> statement-breakpoint
CREATE TABLE "trending_scores" (
	"id" serial PRIMARY KEY NOT NULL,
	"token_id" integer NOT NULL,
	"score" numeric(18, 8) NOT NULL,
	"rank" integer,
	"volume_score" numeric(18, 8),
	"liquidity_score" numeric(18, 8),
	"activity_score" numeric(18, 8),
	"momentum_1h_score" numeric(18, 8),
	"momentum_24h_score" numeric(18, 8),
	"calculated_at" timestamp DEFAULT now() NOT NULL,
	"version" integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"telegram_id" bigint NOT NULL,
	"username" varchar(255),
	"first_name" varchar(255),
	"last_name" varchar(255),
	"is_blocked" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "users_telegram_id_unique" UNIQUE("telegram_id")
);
--> statement-breakpoint
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_session_id_promotion_sessions_id_fk" FOREIGN KEY ("session_id") REFERENCES "public"."promotion_sessions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "market_snapshots" ADD CONSTRAINT "market_snapshots_token_id_tokens_id_fk" FOREIGN KEY ("token_id") REFERENCES "public"."tokens"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_invoice_id_invoices_id_fk" FOREIGN KEY ("invoice_id") REFERENCES "public"."invoices"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "promotion_sessions" ADD CONSTRAINT "promotion_sessions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "promotions" ADD CONSTRAINT "promotions_session_id_promotion_sessions_id_fk" FOREIGN KEY ("session_id") REFERENCES "public"."promotion_sessions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "promotions" ADD CONSTRAINT "promotions_invoice_id_invoices_id_fk" FOREIGN KEY ("invoice_id") REFERENCES "public"."invoices"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "promotions" ADD CONSTRAINT "promotions_receipt_id_receipts_id_fk" FOREIGN KEY ("receipt_id") REFERENCES "public"."receipts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "promotions" ADD CONSTRAINT "promotions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "promotions" ADD CONSTRAINT "promotions_token_id_tokens_id_fk" FOREIGN KEY ("token_id") REFERENCES "public"."tokens"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "receipts" ADD CONSTRAINT "receipts_invoice_id_invoices_id_fk" FOREIGN KEY ("invoice_id") REFERENCES "public"."invoices"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "receipts" ADD CONSTRAINT "receipts_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "trending_scores" ADD CONSTRAINT "trending_scores_token_id_tokens_id_fk" FOREIGN KEY ("token_id") REFERENCES "public"."tokens"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "jobs_status_idx" ON "background_jobs" USING btree ("status");--> statement-breakpoint
CREATE INDEX "jobs_type_idx" ON "background_jobs" USING btree ("type");--> statement-breakpoint
CREATE INDEX "invoices_status_idx" ON "invoices" USING btree ("status");--> statement-breakpoint
CREATE INDEX "invoices_user_idx" ON "invoices" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "snapshots_token_idx" ON "market_snapshots" USING btree ("token_id");--> statement-breakpoint
CREATE INDEX "snapshots_time_idx" ON "market_snapshots" USING btree ("snapshot_at");--> statement-breakpoint
CREATE INDEX "payments_tx_idx" ON "payments" USING btree ("tx_hash");--> statement-breakpoint
CREATE INDEX "sessions_user_idx" ON "promotion_sessions" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "sessions_telegram_idx" ON "promotion_sessions" USING btree ("telegram_id");--> statement-breakpoint
CREATE INDEX "sessions_status_idx" ON "promotion_sessions" USING btree ("status");--> statement-breakpoint
CREATE INDEX "promotions_status_idx" ON "promotions" USING btree ("status");--> statement-breakpoint
CREATE INDEX "promotions_package_idx" ON "promotions" USING btree ("package_code");--> statement-breakpoint
CREATE INDEX "promotions_ends_at_idx" ON "promotions" USING btree ("ends_at");--> statement-breakpoint
CREATE INDEX "posts_hash_idx" ON "published_posts" USING btree ("content_hash");--> statement-breakpoint
CREATE INDEX "tokens_address_idx" ON "tokens" USING btree ("address");--> statement-breakpoint
CREATE INDEX "pairs_factory_idx" ON "trading_pairs" USING btree ("factory_address");--> statement-breakpoint
CREATE INDEX "pairs_token0_idx" ON "trading_pairs" USING btree ("token0_address");--> statement-breakpoint
CREATE INDEX "pairs_token1_idx" ON "trading_pairs" USING btree ("token1_address");--> statement-breakpoint
CREATE INDEX "trending_rank_idx" ON "trending_scores" USING btree ("rank");--> statement-breakpoint
CREATE INDEX "trending_token_idx" ON "trending_scores" USING btree ("token_id");--> statement-breakpoint
CREATE INDEX "users_telegram_id_idx" ON "users" USING btree ("telegram_id");