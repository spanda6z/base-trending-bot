# Base Trending

**Premium Base Network Trending, Token Discovery & Telegram Promotion Platform**

Production-oriented Telegram bot + channel system for organic Base token rankings and paid sponsored placements. Accepts ETH & USDC on Base with on-chain verification.

## Status (as of latest commit)

| Phase | Description | Status |
|-------|-------------|--------|
| 1 | Architecture & planning | ✅ Done |
| 2 | Core scaffolding, webhook, DB schema | ✅ Done |
| 3 | Token scanner + DexScreener | ✅ Done |
| 4 | Full button-driven purchase flow + persistent sessions | ✅ Done |
| 5 | Invoice + ETH/USDC verification + activation + receipt | ✅ Done |
| 6 | Organic trending engine + message formatters | ✅ Core done |
| 7 | Admin commands foundation | ✅ Skeleton |
| 8 | Tests | ⏳ Pending |
| 9 | Live Vercel deploy + webhook registration | ⏳ Needs your env vars |

## What is implemented

- Complete TypeScript + Vercel project
- Full PostgreSQL schema (Drizzle)
- Telegram webhook with secret verification
- Main menu + package/duration selection
- Persistent purchase sessions in DB
- Token contract scanning (bytecode + ERC-20 + DexScreener)
- Social links (Telegram / X / Website) with skip
- Order review → invoice generation
- ETH & USDC payment invoice flow
- On-chain payment verification logic
- Promotion activation + immutable receipts
- Organic trending scoring engine
- Cron stubs (payment reconcile, market refresh, etc.)
- Seed script for packages & slots

## Stack

| Component | Technology |
|-----------|------------|
| Language | TypeScript |
| Runtime | Node.js 20+ |
| Telegram | Telegraf (webhooks only) |
| Hosting | Vercel |
| Database | PostgreSQL (Neon recommended) |
| ORM | Drizzle |
| Blockchain | viem + Base Mainnet |
| Market Data | DexScreener |

## Packages

| Package | 3h | 6h | 12h |
|---------|----|----|-----|
| 🥇 TOP 1 | $500 | $800 | $1,500 |
| 🔥 TOP 5 | $150 | $250 | $400 |
| 📈 TOP 10 | $100 | $150 | $250 |

## Treasury

- Base Mainnet (8453)
- Receiver: `0x1Dad4D6B65dA80CEB7c6937B264132eDD21Dd39E`
- USDC: `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`

## Deploy steps

1. Create Neon database → set `DATABASE_URL`
2. Create Telegram bot → set `TELEGRAM_BOT_TOKEN` + `TELEGRAM_WEBHOOK_SECRET`
3. Add Base RPC URL
4. Connect this repo to Vercel and set all env vars from `.env.example`
5. Deploy
6. Run migrations / `db:push` + `npx tsx scripts/seed.ts`
7. Register webhook:

```bash
curl "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/setWebhook" \
  -d "url=https://YOUR_DOMAIN/api/telegram/webhook" \
  -d "secret_token=$TELEGRAM_WEBHOOK_SECRET"
```

8. Hit `/api/health` to confirm.

## Security

- No private keys in code
- Webhook secret required
- Payments only after on-chain verification
- Receipts only after confirmed settlement
- Organic scores never affected by paid promotions

---

Repository: https://github.com/Nobrain11/Base-Trending
